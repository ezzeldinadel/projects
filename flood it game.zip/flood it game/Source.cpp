#include <SFML/Graphics.hpp>
#include <iostream>
#include <SFML\Audio.hpp>
#include <SFML/System/Time.hpp>
#include <windows.h>
#include <iostream>

using namespace sf;

void data(char A[][20]);
void initialize(char A[][20], RectangleShape[][20]);
void displayBoard(RectangleShape[][20]);
void mainfunc(char col, char A[][20], RectangleShape[][20], int, char);
bool won(char A[][20]);

RenderWindow window(VideoMode(800, 800), "www.Cyber-Forces.cf | FLOOD IT v1.0");

int turns = -1; // counter for moves 


int main()
{
	// hide annoying cmd ( COMMENT THIS PART OUT TO DEBUG AND TEST THE CODE )
	HWND hWnd = GetConsoleWindow();
	ShowWindow(hWnd, SW_HIDE);



	char A[20][20]; // character array 
	char col, y; // col is the current order and y is the current dominating color 
	RectangleShape board[20][20]; // my array representation GUI
	
	
	data(A);
	initialize(A, board);
	

	// welcoming  music 
	Music music;

	if (!music.openFromFile("music.ogg"))
	{
		std::cout << "ERROR" << std::endl;
	}

	music.setVolume(30);

	music.play();
	// end of music 


	// sound handling 
	SoundBuffer buffer;
	SoundBuffer buffer2;

	if (!buffer.loadFromFile("sound.wav"))
	{
		std::cout << "ERROR acessing soundclip " << std::endl;
	}
	if (!buffer2.loadFromFile("lost.wav"))
	{
		std::cout << "ERROR acessing soundclip " << std::endl;
	}

	Sound sound;
	Sound looser, win;
	
	sound.setBuffer(buffer);
	looser.setBuffer(buffer2); 
	win.setBuffer(buffer2);
	// end of sound handling 

	while (window.isOpen())
	{
		//Events

		Event e;
		while (window.pollEvent(e))
		{
			y = A[0][0];
			switch (e.type)
			{
			case Event::Closed:
				window.close();
				break;
			
				
			case Event::KeyPressed:
			
										if (turns < 50 && !won(A)) /////////////////////////////////////////////////////////////// NUMBER OF MOVES BEFORE LOSING
										{
											switch (e.key.code)
											{
											case Keyboard::R:col = 'R';
												if (y != col)
													mainfunc(col, A, board, 0, y);
												turns++;
												sound.play();
												break;
											case Keyboard::B:col = 'B';
												if (y != col)
													mainfunc(col, A, board, 0, y);
												turns++;
												sound.play();
												break;
											case Keyboard::G:col = 'G';
												if (y != col)
													mainfunc(col, A, board, 0, y);
												turns++;
												sound.play();
												break;
											case Keyboard::Y:col = 'Y';
												if (y != col)
													mainfunc(col, A, board, 0, y);
												turns++;
												sound.play();
												break;
											case Keyboard::M:col = 'M';
												if (y != col)
													mainfunc(col, A, board, 0, y);
												turns++;
												sound.play();
												break;
											case Keyboard::C:col = 'C';
												if (y != col)
													mainfunc(col, A, board, 0, y);
												turns++;
												sound.play();
												break;
											case Keyboard::Escape:
												return 0;
												break;
											}

										}

										else if (won(A))
										{// YOU won  !!
											if (!buffer2.loadFromFile("applause.wav"))
											{
												std::cout << "ERROR acessing soundclip " << std::endl;
											}

											// text 
											music.stop();
											sf::Text text;
											sf::Font font;
											font.loadFromFile("arial.ttf");
											text.setString("YOU WON !");
											text.setPosition(Vector2f(130, 300));
											text.setFont(font);
											text.setColor(sf::Color::Green);
											text.setCharacterSize(70);
											text.setStyle(sf::Text::Bold | sf::Text::Italic);

											window.clear(Color::Black);
											window.draw(text);
											window.display();

											win.play();
											sleep(seconds(6));
											return 0;

										}
										else if ( turns >= 50) ///////////////////////////////////////////////////// number of moves here too
										{ // YOU LOST  !!
											// text 
											music.stop();
											sf::Text text;
											sf::Font font;
											font.loadFromFile("arial.ttf");
											text.setString("YOU LOST !\n too much moves \n... too few victories");
											text.setPosition(Vector2f(30, 300));
											text.setFont(font);
											text.setColor(sf::Color::Red);
											text.setCharacterSize(70);
											text.setStyle(sf::Text::Bold | sf::Text::Underlined);

											window.clear(Color::Black);
											window.draw(text);
											window.display();

											looser.play();
											sleep(seconds(6));
											return 0;
										}
	
				break;
			}
		}

		if (turns != -1)
		{
			Font font;
			font.loadFromFile("arial.ttf");
			std::string temp = " Moves : ";
			// std::string ez = std::to_string(coinscounter);
			Text text2(temp + std::to_string(turns), font, 50);
			text2.setColor(sf::Color::Black);
			text2.setPosition(500, 600);


			initialize(A, board);
			window.clear(Color::White);
			displayBoard(board);
			window.draw(text2);
			window.display();
		}
		else { // intro 
			
			sf::Texture texture;
			texture.setRepeated(true);

			if (!texture.loadFromFile("photo.png"))
			{
				std::cout << "Error loading paddle texture :(" << std::endl;
			}

			sf::Sprite sprite;
			sprite.setPosition(130, 0);
			sprite.setTexture(texture);
			sprite.setTextureRect(sf::IntRect(0, 0, 535, 685));
			
			window.clear(Color::White);
			window.draw(sprite);
			window.display();
			
			sleep(seconds(5));

			
			sf::Texture texture2;
			texture2.setRepeated(true);

			if (!texture2.loadFromFile("cont.png"))
			{
				std::cout << "Error loading paddle texture :(" << std::endl;
			}

			sf::Sprite sprite2(texture2);
			window.clear(Color::White);
			window.draw(sprite2);
			window.display();
			sleep(seconds(5));

			turns = 0;
		}
	}
	return 0;

}


bool won(char A[][20])
{
	int i = 0, j = 0; // cols & rows 
	char last = A[19][19]; // save the last box ( far lower right )
	bool flag = 1; // assume the guy won 

	for (int i = 0; i < 20 && flag; i++)
		for (int j = 0; j < 20 && flag; j++)
			if (last != A[i][j]) // if theyre not equal 
				flag = 0; // then the guy didnt win yet 

	return flag;
}


void data(char A[][20])
{
	srand(unsigned(time(NULL)));
	int x;
	for (int i = 0; i < 20; i++)
		for (int j = 0; j < 20; j++)
		{
			x = rand() % 6;
			switch (x)
			{
			case 0:
				A[i][j] = 'R';
				break;
			case 1:
				A[i][j] = 'C';
				break;
			case 2:
				A[i][j] = 'Y';
				break;
			case 3:
				A[i][j] = 'G';
				break;
			case 4:
				A[i][j] = 'B';
				break;
			case 5:
				A[i][j] = 'M';
				break;
			}
		}
}

void initialize(char A[][20], RectangleShape board[20][20])
{
	for (int i = 0; i < 20; i++)
		for (int j = 0; j < 20; j++)
		{
			board[i][j].setSize(Vector2f(40, 40));
			board[i][j].setPosition(i * 40, j * 40);
			switch (A[i][j])
			{
			case 'R':
				board[i][j].setFillColor(sf::Color::Red);
				break;
			case 'C':
				board[i][j].setFillColor(sf::Color::Cyan);
				break;
			case 'Y':
				board[i][j].setFillColor(sf::Color::Yellow);
				break;
			case 'G':
				board[i][j].setFillColor(sf::Color::Green);
				break;
			case 'B':
				board[i][j].setFillColor(sf::Color::Blue);
				break;
			case 'M':
				board[i][j].setFillColor(sf::Color::Magenta);
				break;

			}
		}
}

void displayBoard(RectangleShape board[][20])
{
	for (int i = 0; i < 20; i++)
	{
		for (int j = 0; j < 20; j++)
		{
			window.draw(board[i][j]);
		}
	}
}


void mainfunc(char col, char A[][20], RectangleShape board[][20], int i, char y)
{
	
	A[i / 20][i % 20] = col;

	if (i != 19)
	{
		if ((A[i / 20][(i + 1) % 20] == y) && (i % 20 != 19))
		{
			mainfunc(col, A, board, i + 1, y);
		}
	}
	if (i != 0)
	{
		if ((A[i / 20][(i - 1) % 20] == y) && (i % 20 != 0))
		{
			mainfunc(col, A, board, i - 1, y);
		}

	}
	if (i >= 20)
	{
		if (A[(i - 20) / 20][i % 20] == y)
		{
			mainfunc(col, A, board, i - 20, y);
		}
	}
	if (i <= 20 * 20 - 20 - 1)
	{
		if (A[(i + 20) / 20][i % 20] == y)
		{
			mainfunc(col, A, board, i + 20, y);
		}
	}

}